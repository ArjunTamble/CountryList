import React, { Component } from 'react';
import axios from 'axios';
import SearchBox from './SearchBox'
import EachCountryDetails from './EachCountryDetails'

class CountryListView extends Component {
	constructor(){
		super();

		this.state = {
			fullList: [],
			filteredList: [],
			selectedCountry: []
		};

		this.searchInput = this.searchInput.bind(this);
		this.countryDetails = this.countryDetails.bind(this);
	}

	//When user types country name in the dearch field
	searchInput(e){
		let name = e.target.value.toUpperCase();
		let filteredList = this.state.fullList.filter(val=>val.name.toUpperCase().indexOf(name)===0);
		this.setState({
			...this.state,
			filteredList
		});
	}

	//When user clicks on a country name in the list
	countryDetails(e){
		let countryName = e.target.innerText.trim();
		let countryDetails = this.state.fullList.filter(val=>val.name.indexOf(countryName)===0);
		this.setState({
			...this.state,
			selectedCountry: countryDetails
		}, ()=>{
			document.body.scrollTop = 0;
  			document.documentElement.scrollTop = 0;
		});
	}

	render(){
		let { fullList, filteredList, selectedCountry } = this.state;
		let list;

		if(filteredList.length > 0)
			list = filteredList.map((country, index)=>(<li className="country-list" onClick={this.countryDetails} key={index}>{country.name}</li>))
		else
			list = fullList.map((country, index)=>(<li className="country-list" onClick={this.countryDetails} key={index}>{country.name}</li>))
		
		return (
			<div className="parent-container">
				<h2>Countries</h2>
				<SearchBox searchInput={this.searchInput}/>
				<div className="container">
					<div className="list-section">
						<ul>
							{ list }
						</ul>
					</div>
					<EachCountryDetails selectedCountry={selectedCountry}/>
				</div>
			</div>
		)
	}

	componentDidMount(){
		axios.get('https://restcountries.eu/rest/v2/all').then(response => {
			this.setState({
				...this.state,
				fullList: response.data
			});
		})
	}
}

export default CountryListView;
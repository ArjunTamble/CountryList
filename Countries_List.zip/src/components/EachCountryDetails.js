import React, { Component } from 'react';

class EachCountryDetails extends Component {
	render(){
		let { selectedCountry: country } = this.props;
		let table;
		if(country.length == 1){
			table = (
				<table>
					<tbody>
						<tr>
							<td><b>Country Name:</b></td>
							<td>{country[0].name}</td>
						</tr>
						<tr>
							<td><b>Flag:</b></td>
							<td><img src={"https://www.countryflags.io/"+country[0].alpha2Code+"/flat/64.png"} width="50px" /></td>
						</tr>
						<tr>
							<td><b>Language:</b></td>
							<td>{country[0].languages.map(name=>name.name+' ')}</td>
						</tr>
						<tr>
							<td><b>Capital:</b></td>
							<td>{country[0].capital}</td>
						</tr>
						<tr>
							<td><b>Calling Code:</b></td>
							<td>{country[0].callingCodes[0]}</td>
						</tr>
						<tr>
							<td><b>Currency:</b></td>
							<td>{country[0].currencies[0].name}</td>
						</tr>
						<tr>
							<td><b>Region:</b></td>
							<td>{country[0].region}</td>
						</tr>
						<tr>
							<td><b>Sub Region</b></td>
							<td>{country[0].subregion}</td>
						</tr>
						<tr>
							<td><b>Population:</b></td>
							<td>{country[0].population}</td>
						</tr>
					</tbody>
				</table>
			)
		} else {
			table = (
			 <p> Click on a country to view it's details here </p>
			)
		};

		return (
			<div className="country-info">
				{ table }
			</div>
		)
	}
}

export default EachCountryDetails;
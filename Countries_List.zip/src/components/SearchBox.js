import React, { Component } from 'react';

class SearchBox extends Component {
	render(){
		const { searchInput, search } = this.props;
		return (
			<div>
				<input className="search-box" type="text" onChange={searchInput} placeholder="Search for country"/>
			</div>
		)
	}
}

export default SearchBox;
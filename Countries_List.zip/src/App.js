import React from 'react';
import logo from './logo.svg';
import './App.css';
import CountryListView  from './components/CountryListView'

function App() {
  return (
    <CountryListView />
  );
}

export default App;